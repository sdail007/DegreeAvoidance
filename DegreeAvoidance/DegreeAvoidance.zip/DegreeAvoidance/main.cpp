//
//  main.cpp
//  DegreeAvoidance
//
//  Created by Stephen Dailey on 4/1/14.
//  Copyright (c) 2014 Stephen Dailey. All rights reserved.
//

#include <iostream>
#include "GraphComponents.h"
#include "RemainingDegreeGraph.h"
#include <vector>

using namespace std;

int main(int argc, const char * argv[])
{
    Graph myGraph = Graph(5);
    cout << myGraph << endl;
	myGraph.addEdge(&myGraph.getVertex(1), &myGraph.getVertex(3));
	cout << myGraph << endl;
	
	vector<int> ds = myGraph.getDegreeSequence();
	for(int i = 0; i < ds.size(); i++)
	{
		cout << ds[i] << " ";
	}
	cout << endl;
	myGraph.removeEdge(Edge(&myGraph.getVertex(1), &myGraph.getVertex(3)));
	cout << myGraph << endl;
	myGraph.addEdge(&myGraph.getVertex(1), &myGraph.getVertex(3));
	cout << myGraph << endl;
	
	RemainingDegreeGraph myGraph2 = RemainingDegreeGraph(5);
    cout << myGraph2 << endl;
	return 0;
}

